package me.dio.academia.digital.repository;

public interface AlunoRepository {
}
